import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AdminRoutingModule } from "./admin-routing.module";
import { AdminComponent } from "./admin.component";
import { HomeComponent } from "./home/home.component";
import { UserComponent } from "./user/user.component";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from "../_shared/shared.module";
import { SidebarMenuComponent } from "../_shared/sidebar-menu/sidebar-menu.component";
import { HeaderComponent } from "../_shared/header/header.component";
import { NavService } from "../_services/nav.service";
@NgModule({
    providers: [
      NavService
    ],
    imports: [
      CommonModule,
      RouterModule,
      AdminRoutingModule,
      NgbModule,
      FontAwesomeModule,
      SharedModule
    ],
    declarations: [
            HomeComponent, 
            UserComponent,
            SidebarMenuComponent,
            HeaderComponent
            ],
            exports: [
              NgbModule,
              FontAwesomeModule,
              SharedModule
              
            ],
    bootstrap: [AdminComponent]
  })
  export class AdminModule {}
  