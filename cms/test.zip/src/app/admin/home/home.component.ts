import { Component, OnInit, ViewChild } from '@angular/core';
import { UserComponent } from '../user/user.component';
import { faAlignLeft,faAlignJustify,faCaretDown } from '@fortawesome/free-solid-svg-icons';
import { ajax } from 'rxjs/ajax';
import { map } from 'rxjs/operators'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @ViewChild('child') public child: UserComponent;
  constructor() { }
  public isCollapsed = false;
  faAlignLeft = faAlignLeft;
  faAlignJustify = faAlignJustify;
  ngOnInit(): void {
   
  }

  showAlert(data:any)
  {
    console.log('data is' + data)
  }

  displayCounter(count: any) {
    console.log('value'+ count);
  }

  getData() {
    const response =
    ajax('https://jsonplaceholder.typicode.com/users')
       .pipe(map(e => e.response));
    response.subscribe(res => {
       console.log(res);
      //  this.data = res;
    });
 }
}
