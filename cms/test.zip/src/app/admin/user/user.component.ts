import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
 
  @Output() valueChange = new EventEmitter();
  
  constructor() { }
  counter = 0;
  ngOnInit(): void {
  }
  valueChanged() {
    this.counter = this.counter + 1;
    this.valueChange.emit(this.counter);
}
}
