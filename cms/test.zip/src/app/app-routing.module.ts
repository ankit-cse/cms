import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthenticationGuard } from './_helpers/authentication.guard';


const routes: Routes = [ 
{ path: '', redirectTo:'/signup' , pathMatch: 'full'},
{ path: 'signup', component: RegisterComponent },
{ path: 'login', component: LoginComponent,canActivate:[AuthenticationGuard] },
{ path: 'admin'            , loadChildren: () => import('./admin/admin-routing.module').then(m => m.AdminRoutingModule)}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
