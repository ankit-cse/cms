import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';



const AUTH_API = 'https://reqres.in/api/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }
  public get baseUrl(){return environment.baseUrl}


  register(user): Observable<any> {
    return this.http.post(AUTH_API + 'register',user,httpOptions);
  }
  login(user): Observable<any> {
    return this.http.post( this.baseUrl + '/api/register/authenticate',user,httpOptions);
  }
}