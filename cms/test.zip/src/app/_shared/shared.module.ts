import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SidebarMenuComponent } from "./sidebar-menu/sidebar-menu.component";
@NgModule({
  providers: [
  ],
  imports: [
    CommonModule,
    RouterModule,
    NgbModule,
    FontAwesomeModule,
  ],
  declarations: [

  ],
  exports: [
    NgbModule,
    FontAwesomeModule

  ],
  bootstrap: []
})
export class SharedModule { }
