import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../_helpers/must-match.validator';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private authService:AuthService,private formBuilder: FormBuilder) { }
  registrationform: FormGroup;
  submitted = false;
  ngOnInit(): void {
    this.registrationform = this.formBuilder.group({
      name:           new FormControl("",Validators.required),
      email:           new FormControl("",[Validators.required,Validators.email]),
      contact:           new FormControl("",[Validators.required,Validators.minLength(10)]),
      password:        new FormControl("",Validators.required),
      confirmPassword: new FormControl ("",Validators.required)}, 
      { validator: MustMatch('password', 'confirmPassword')
    });
}
  get f() { return this.registrationform.controls; }
  onSubmit()
  {
    this.submitted = true;
    console.log(this.submitted)
    // stop here if form is invalid
    if (this.registrationform.invalid) {
        return;
    }
    console.log(this.registrationform.value)
      
      // this.authService.register(this.registrationform.value).subscribe(
      //   data => {
      //     console.log(data);
         
      //   },
      //   err => {
        
      //   }
      // );
    
  }
}
