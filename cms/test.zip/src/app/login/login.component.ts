import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { from, of } from 'rxjs';
import { endWith, map } from 'rxjs/operators';
import { AuthService } from '../_services/auth.service';
const source = from([
  { name: 'Joe', age: 30 },
  { name: 'Frank', age: 20 },
  { name: 'Ryan', age: 50 }
]);

const source$ = of('Hello', 'Friend', 'Goodbye');
source$.pipe(endWith('Friend'))
  // 'Hello', 'Friend', 'Goodbye', 'Friend'
  .subscribe(val => console.log(val));
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  registrationform: FormGroup;
  submitted = false;
  
  constructor(private authService:AuthService,private router: Router) {
    
   }

  get f() { 
    console
    return this.registrationform.controls; }
  ngOnInit() {
    this.registrationform = new FormGroup({
      username:           new FormControl("",Validators.required),
      password:        new FormControl("",Validators.required),
  });
  }
  onSubmit()
  {
    console.log(this.registrationform.value);
    this.submitted = true;
    if (this.registrationform.invalid) {
        return;
    }
    this.router.navigateByUrl('/admin');
    // this.authService.login(this.registrationform.value).subscribe(
    //   data => {
    //     console.log('login token' + data);
       
    //   },
    //   err => {
      
    //   }
    // );
  }
  ngDoCheck()
  {
    console.log("do check called");
  }
  ngOnDestroy ()
  {
    console.log("distroy called");
  }
}
